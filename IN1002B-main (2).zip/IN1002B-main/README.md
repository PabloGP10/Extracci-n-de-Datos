# IN1002B
Repositorio de apoyo para mis alumnos del bloque: Desarrollo de proyectos de análisis de datos 
